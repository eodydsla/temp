library(mapview)
library(leaflet)
library(sf)
library(htmlwidgets)

# 데이터를 불러옵니다.
data <- st_read("./시도_[2017]_녹지(녹피)면적비율_-_1인당_녹지(녹피)면적.shp", options = "Encoding=euc-kr")

# 좌표계를 WGS 84로 변환 (EPSG: 4326)
data <- st_transform(data, crs = 4326)

# 데이터 간소화 (단순화 정도를 설정할 수 있습니다. 예: dTolerance)
data_simplified <- st_simplify(data, dTolerance = 1000)

# 색상 팔레트 설정
pal_gr_area_m <- colorNumeric("viridis", domain = data_simplified$GR_AREA_M)
pal_gr_area_pp <- colorNumeric("viridis", domain = data_simplified$GR_AREA_PP)

# popup 내용을 생성합니다 (예: 지역 이름과 면적 정보를 포함)
popup_content <- paste0(data_simplified$ADM_NM, 
                        "<br><strong>GR_AREA_M: </strong>", data_simplified$GR_AREA_M,
                        "<br><strong>GR_AREA_PP: </strong>", data_simplified$GR_AREA_PP)

# leaflet 객체 생성
leaflet_map <- leaflet(data_simplified) %>%
  addTiles()

# 첫 번째 레이어 추가: "GR_AREA_M"
leaflet_map <- leaflet_map %>%
  addPolygons(fillColor = ~pal_gr_area_m(GR_AREA_M),
              fillOpacity = 0.7, weight = 1, color = "#BDBDC3", group = "GR_AREA_M",
              popup = popup_content)

# 두 번째 레이어 추가: "GR_AREA_PP"
leaflet_map <- leaflet_map %>%
  addPolygons(fillColor = ~pal_gr_area_pp(GR_AREA_PP),
              fillOpacity = 0.7, weight = 1, color = "#BDBDC3", group = "GR_AREA_PP",
              popup = popup_content)

# 레이어 컨트롤 추가
leaflet_map <- leaflet_map %>%
  addLayersControl(
    overlayGroups = c("GR_AREA_M", "GR_AREA_PP"),
    options = layersControlOptions(collapsed = FALSE)
  )

# 첫 번째 레이어에 대한 범례 추가
leaflet_map <- leaflet_map %>%
  addLegend(pal = pal_gr_area_m, values = ~GR_AREA_M, opacity = 0.7, title = "GR_AREA_M", group = "GR_AREA_M")

# 두 번째 레이어에 대한 범례 추가
leaflet_map <- leaflet_map %>%
  addLegend(pal = pal_gr_area_pp, values = ~GR_AREA_PP, opacity = 0.7, title = "GR_AREA_PP", group = "GR_AREA_PP")

# HTML 파일로 저장
saveWidget(leaflet_map, "leaflet_map.html", selfcontained = FALSE)

# 지도 출력